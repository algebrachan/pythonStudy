from django.db import models

# Create your models here.
class activity(models.Model):
    # class Meta:
    #     db_table='activities_activity'

        id = models.AutoField(primary_key=True)
        name = models.CharField(max_length=20)
        cost = models.CharField(max_length=20)
        deposit = models.CharField(max_length=20)
        activity_price_deposit = models.CharField(max_length=20)
        toplimit = models.CharField(max_length=20)
        Statement = models.CharField(max_length=20)

class photo(models.Model):
    id = models.AutoField(primary_key=True)
    photo=models.CharField(max_length=48),
    activity_id=models.ForeignKey('activity',on_delete=models.SET_NULL,null=True,blank=True)


class record(models.Model):
    id = models.AutoField(primary_key=True)
    activity_id=models.ForeignKey('activity',on_delete=models.SET_NULL,null=True,blank=True)
    user_id=models.CharField(max_length=20)
    student_name=models.CharField(max_length=20)
    student_age=models.IntegerField(max_length=5)
    phone=models.IntegerField(max_length=20)
    Datetime=models.DateTimeField(max_length=20)

